package 装饰模式不懂;

public class PrettyDecorator extends Decorator{
    public PrettyDecorator(Person person) {
        super(person);
    }

    @Override
    public void show() {
    this.getPerson().show();
    this.pretty();
//        System.out.println(this);
    }
    public void pretty(){
        System.out.println("帅...");
    }

}
