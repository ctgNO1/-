package 装饰模式不懂;

public class RichDecorator extends Decorator{
    public RichDecorator(Person person) {
        super(person);
    }

    @Override
    public void show() {
        this.getPerson().show();
        this.rich();
        System.out.println(this);
    }

    public void rich(){
        System.out.println("富...");
    }
}
