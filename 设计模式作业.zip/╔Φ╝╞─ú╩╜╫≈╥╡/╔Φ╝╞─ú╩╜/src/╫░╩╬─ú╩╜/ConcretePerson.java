package 装饰模式不懂;

public class ConcretePerson implements Person{
    @Override
    public void show() {
        System.out.println("人。。。。");
    }
}
