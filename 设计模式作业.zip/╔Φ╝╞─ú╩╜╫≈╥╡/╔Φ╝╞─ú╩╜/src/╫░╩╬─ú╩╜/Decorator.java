package 装饰模式不懂;

public abstract class  Decorator implements Person {
    private Person person; //装饰对象包含一个对真实对象的引用
    public Decorator(Person person) {
        this.person = person;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    @Override
    public abstract void show();
}
