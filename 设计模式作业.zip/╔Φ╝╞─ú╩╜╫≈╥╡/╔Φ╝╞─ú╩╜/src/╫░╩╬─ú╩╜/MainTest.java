package 装饰模式不懂;

/**
 *    继续看；
 */


public class MainTest {
    public static void main(String[] args) {
        Person person=new ConcretePerson();
//        Decorator decorator =new HeightDecorator(person);
//        decorator.show();
//        Decorator decorator2 =new RichDecorator(person);
//        decorator2.show();
//        Decorator decorator3 =new PrettyDecorator(person);
//        decorator3.show();


        /**
         *给人进行属性的组合
         * */
        Decorator height= new HeightDecorator(person);
        Decorator rich= new RichDecorator(height);
        Decorator preety= new PrettyDecorator(rich);
        System.out.println(preety);
        preety.show();


    }
}
