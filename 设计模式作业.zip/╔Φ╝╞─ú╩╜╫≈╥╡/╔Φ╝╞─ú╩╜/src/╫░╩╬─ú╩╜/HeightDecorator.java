package 装饰模式不懂;

public class HeightDecorator extends Decorator{
    public HeightDecorator(Person person) {
        super(person);
    }

    @Override
    public void show() {
        this.getPerson().show();//此时 this代表 父类对象
        this.height();
        System.out.println(this);

    }

    public void height(){
        System.out.println("高...");
    }

}
