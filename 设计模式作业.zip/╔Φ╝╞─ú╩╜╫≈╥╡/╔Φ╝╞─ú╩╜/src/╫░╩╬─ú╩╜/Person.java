package 装饰模式不懂;

public interface Person {
    public void show();
}
