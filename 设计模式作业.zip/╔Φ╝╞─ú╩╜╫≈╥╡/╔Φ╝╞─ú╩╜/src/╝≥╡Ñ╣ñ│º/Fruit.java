package 简单工厂;

public interface Fruit {
    //生产水果
    public void get();


}
