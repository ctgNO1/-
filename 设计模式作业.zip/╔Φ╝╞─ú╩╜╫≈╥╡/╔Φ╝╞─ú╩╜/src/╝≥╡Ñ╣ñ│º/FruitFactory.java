package 简单工厂;

public class FruitFactory {
    //第一种方式--简单
//    public static 简单工厂.Fruit getApple(){
//        return new 简单工厂.Apple();
//    }
//    public static 简单工厂.Fruit getPear(){
//        return new 简单工厂.Pear();
//    }

    //第二种工厂模式
    //依据参数这个方法用来返回水果对象
    public static Fruit getFruit(String type){
        if ("apple".equals(type)){
            return new Apple();
        }else if ("pear".equals(type)){
            return new Pear();
        }else{
            return null;
        }
    }

}
