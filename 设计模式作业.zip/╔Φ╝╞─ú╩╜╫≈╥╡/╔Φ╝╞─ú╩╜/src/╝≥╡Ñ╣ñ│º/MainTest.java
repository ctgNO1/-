package 简单工厂;

public class MainTest {
    public static void main(String[] args) {
        //调用生产
        //1使用多态的方式
//        简单工厂.Fruit apple=new 简单工厂.Apple();
//        简单工厂.Fruit pear=new 简单工厂.Pear();
//        apple.get();
//        pear.get();

        //2简单工厂模式
        //核心：所有水果的创建权限交给工厂
        //将工厂方法改为静态方法，无需new工厂对象
        FruitFactory.getFruit("apple").get();

//        System.out.println(Integer.parseInt("+"));


    }
}
