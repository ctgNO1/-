package 简单工厂;

public class Pear implements Fruit {
    @Override
    public void get() {
        System.out.println("生产梨子");
    }
}

