package 简单工厂;

import java.util.HashMap;
import java.util.Map;

public class Apple implements Fruit{

    @Override
    public void get() {
        System.out.println("生产苹果");
    }
}
