package 外观模式;

/**
*财务子系统
* */
public class MoneySystem {
    //收款
    public void in(){
        System.out.println("付款");
    }
    //退款
    public void out(){
        System.out.println("退款");
    }


}
