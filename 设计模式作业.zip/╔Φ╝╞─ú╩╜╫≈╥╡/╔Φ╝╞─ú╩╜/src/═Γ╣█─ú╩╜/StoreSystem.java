package 外观模式;

/**
 * 库存自系统，
 */

public class StoreSystem {
    public void ruku(){
        System.out.println("入库");
    }
    public void chuku(){
        System.out.println("出库");
    }
}
