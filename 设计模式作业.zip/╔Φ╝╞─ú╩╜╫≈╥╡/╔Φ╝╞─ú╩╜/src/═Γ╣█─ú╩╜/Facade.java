package 外观模式;

//这个类为外观
public class Facade {
    private  MoneySystem moneySystem;
    private  OrderSystem orderSystem;
    private  StoreSystem storeSystem;

    public Facade() {
        this.moneySystem = new MoneySystem();
        this.orderSystem = new OrderSystem();
        this.storeSystem = new StoreSystem();
    }
    //下达订单
    public void createOrder(){
        orderSystem.create();
        storeSystem.chuku();
        moneySystem.in();
    }
    //入库操作
    public void ruku(){
        storeSystem.ruku();

    }
    //退款(不退货)
    public void tuikuan(){
        moneySystem.out();
        orderSystem.tui();

    }



}
