package 外观模式;

public class OrderSystem {

    public void create(){
        System.out.println("下达订单");
    }
    public void tui(){
        System.out.println("订单退货");
    }


}
