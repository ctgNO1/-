package 外观模式;

public class MainTest {

    public static void main(String[] args) {
        //客户下达订单
        Facade facade=new Facade();
//        facade.createOrder();
//        产品入库
        facade.ruku();
        //退款
        facade.tuikuan();
    }
}
