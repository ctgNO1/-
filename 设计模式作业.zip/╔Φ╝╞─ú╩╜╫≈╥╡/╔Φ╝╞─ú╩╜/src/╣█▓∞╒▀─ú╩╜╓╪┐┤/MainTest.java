package 观察者模式重看;

public class MainTest {
    public static void main(String[] args) {
        //new 被观察者类对象
        ArticleOperation articleOperation =new ArticleOperation();
        //注册观察者类
        articleOperation.addObserver(new MyObserver());
        articleOperation.addObserver(new MyObserver2());
        articleOperation.publish("你好世界","我是观察者模式测试","admain");


    }
}
