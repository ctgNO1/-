package 观察者模式重看;

import java.util.Observable;

//被观察者需要继承Observable类
public class ArticleOperation extends Observable {
//    Observable是具体类，也能被继承
    public void publish(String title,String content,String author){
        Article article=new Article();
        article.setTitle(title);
        article.setContent(content);
        article.setAuthor(author);
        //将这篇文章推送给观察者---状态改变
        this.setChanged();
        this.notifyObservers(article);

    }

}
