package 建造者模式;

public class louFangHouseBuilder implements HouseBuilder{
    private House house =  new House();

    @Override
    public void makeFloor() {

        house.setFloor("楼房--地板");

    }

    @Override
    public void makeTop() {

        house.setTop("楼房--房顶");

    }

    @Override
    public void makeWall() {

        house.setWall("楼房--墙壁");

    }

    @Override
    public House getHouse(){
        return house;
    }


}
