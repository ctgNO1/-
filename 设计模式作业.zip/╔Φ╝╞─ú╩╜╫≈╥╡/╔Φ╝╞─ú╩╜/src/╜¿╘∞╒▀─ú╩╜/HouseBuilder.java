package 建造者模式;

public interface HouseBuilder {
    public void makeFloor();
    public void makeTop();
    public void makeWall();
    public House getHouse();

}
