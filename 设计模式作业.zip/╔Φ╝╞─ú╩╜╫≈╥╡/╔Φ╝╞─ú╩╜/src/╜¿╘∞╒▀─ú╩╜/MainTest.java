package 建造者模式;

public class MainTest {
    public static void main(String[] args) {
//        House house= new House();
//        house.setFloor("地板");
//        house.setWall("墙壁");
//        house.setTop("房顶");
//        System.out.println(house.getFloor());
//        System.out.println(house.getTop());
//        System.out.println(house.getWall());

        //使用建造者模式--将复杂的创建过程，按照方法来存在
//
//        HouseBuilder houseBuilder=new PingFangHouseBuilder();
//        houseBuilder.makeFloor();
//        houseBuilder.makeTop();
//        houseBuilder.makeWall();
//        House house=houseBuilder.getHouse();
//        System.out.println(house.getWall());
//        System.out.println(house.getTop());
//        System.out.println(house.getFloor());


        //还是不够简单---引入设计者，简化客户端的调用操作
        //1定义一个房屋的建造者
        HouseBuilder houseBuilder=new PingFangHouseBuilder();
        System.out.println(houseBuilder.getHouse());

        //2定义一个设计者
        HouseDirector houseDirector=new HouseDirector(houseBuilder);
        houseDirector.make();
        houseDirector.println();
//        System.out.println(house.getFloor());
//        System.out.println(house.getTop());
//        System.out.println(house.getWall());





    }
}
