package 建造者模式;

public class HouseDirector {
    //指挥者依赖于 HouseBuilder接口信息，同时通过构造的方式将 其注入进来
   private HouseBuilder houseBuilder;//
    //简化建造房子的操作过程
    public House make(){
        houseBuilder.makeWall();
        houseBuilder.makeTop();
        houseBuilder.makeFloor();
        //还可以做一些复杂的业务处理
        return houseBuilder.getHouse();
    }
    public HouseDirector(HouseBuilder houseBuilder) {
        this.houseBuilder = houseBuilder;
    }
    public void println(){
        System.out.println(houseBuilder.getHouse().getWall());
        System.out.println(houseBuilder.getHouse().getTop());
        System.out.println(houseBuilder.getHouse().getFloor());

    }


}
