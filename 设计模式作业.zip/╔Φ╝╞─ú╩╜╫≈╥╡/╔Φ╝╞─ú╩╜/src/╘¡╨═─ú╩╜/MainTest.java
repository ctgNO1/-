package 原型模式;

public class MainTest {
    public static void main(String[] args) {
        Student s1=new Student();
        s1.setId(1);
        s1.setName("张三");
        s1.setSex("男");
        System.out.println(s1);
        System.out.println(s1.getName());
        System.out.println(s1.getId());
        System.out.println(s1.getSex());

        //如何实现克隆
        //1.实现cloneable接口---具体类实现---这个接口的目的是为了告诉java虚拟机这个对象是可以被克隆的
        //2.重写Object类的clone方法
        try {
            Student s3=s1.clone();
            s3.setName("李四");
            System.out.println(s3);
            System.out.println(s3.getSex());
            System.out.println(s3.getId());
            System.out.println(s3.getName());
    /*克隆出来的对象是在 新的地址空间中开辟的对象，和原本的只是值一样，但是地址空间不一样
    * */

        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
    }
}
