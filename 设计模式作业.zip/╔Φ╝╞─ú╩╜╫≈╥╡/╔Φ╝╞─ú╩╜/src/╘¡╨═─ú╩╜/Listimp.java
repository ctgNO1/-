package 原型模式;

import java.util.List;

public abstract class  Listimp implements List {
    @Override
    public String toString() {
        return getClass().getName() + "@" + Integer.toHexString(hashCode());
    }
}
