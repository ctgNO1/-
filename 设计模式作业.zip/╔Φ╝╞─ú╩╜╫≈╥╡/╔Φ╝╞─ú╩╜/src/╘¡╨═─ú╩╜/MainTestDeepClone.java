package 原型模式;

import java.util.ArrayList;
import java.util.List;


/**
 * 并没有实现  集合的深度克隆
* */

@SuppressWarnings("all")
public class MainTestDeepClone {
        public static void main(String[] args) {
            Student s1=new Student();
            s1.setId(1);
            s1.setName("张三");
            s1.setSex("男");
            List<String> list=new ArrayList<>();//我们想看一下针对这种符合数据类型的克隆效果
            //测试结果 list集合 如果 直接添加值，也能够打印出来
            list.add("abcd");
            list.add("efgh");
            s1.setList(list);
            //数组测试
            String arr[]=new String[2];
            arr[0]="我爱你";
            arr[1]="你爱他";
            s1.setArr(arr);
            System.out.println(s1);
            System.out.println(s1.getName());
            System.out.println(s1.getId());
            System.out.println(s1.getSex());
            System.out.println(s1.getList1());
            System.out.println(s1.getArr());



            //如何实现克隆
            //1.实现cloneable接口---具体类实现---这个接口的目的是为了告诉java虚拟机这个对象是可以被克隆的
            //2.重写Object类的clone方法
            try {
                Student s3=s1.clone();
                s3.setName("李四");
                List <String> list1 =new ArrayList();
                for (String str: list){
                    list1.add(str);
                }
                s3.setList(list1);
                System.out.println(s3);
                System.out.println(s3.getSex());
                System.out.println(s3.getId());
                System.out.println(s3.getName());
                System.out.println(s3.getList1());//集合虽然.hashcode()方法的值一样，但是通过对其对象的打印，发现集合无需修改本身就是深度克隆
                System.out.println(s3.getArr());

                /*克隆出来的是在 新的地址空间中开辟的对象，和原本的只是值一样，但是地址空间不一样
                 * */

                //数组集合测试----克隆出来的对象内数组集合地址空间一致，但是对象的地址空间不一样；

            } catch (CloneNotSupportedException e) {
                e.printStackTrace();
            }
        }
    }


