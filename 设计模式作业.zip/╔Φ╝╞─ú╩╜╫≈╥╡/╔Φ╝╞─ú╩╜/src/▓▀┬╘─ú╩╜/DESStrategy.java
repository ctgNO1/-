package 策略模式;

public class DESStrategy implements Strategy{
    @Override
    public void encrypt() {
        System.out.println("DES加密");
    }
}
