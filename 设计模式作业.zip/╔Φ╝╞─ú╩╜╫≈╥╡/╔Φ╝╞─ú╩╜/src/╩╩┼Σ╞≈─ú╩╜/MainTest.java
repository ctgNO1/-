package 适配器模式;

public class MainTest {
    public static void main(String[] args) {

        //需要被适配的类
        Adapee220 adapee220=new Adapee220();
        //接口调用适配器
        Target18 target18=new Adaper(adapee220);
        //最终输出的结果
        target18.a18();
    }
}
