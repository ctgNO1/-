package 适配器模式;

public class Adapee220 {
    public void show(){
        System.out.println("输出220v");
    }
}
