package 适配器模式;

public interface Target18 {
    public void  a18();
}
