package 适配器模式;

public class Adaper implements Target18 {
    //引入被适配的类对象
    private Adapee220 adapee220;


    public Adaper(Adapee220 adapee220) {
        this.adapee220 = adapee220;
    }

    @Override
    public void a18() {
    adapee220.show();
        System.out.println("将220v转化为18v电压");
    }

}
