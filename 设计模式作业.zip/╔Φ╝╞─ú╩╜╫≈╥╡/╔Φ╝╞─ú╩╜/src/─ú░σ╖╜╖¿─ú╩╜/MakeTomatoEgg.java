package 模板方法模式;

public class MakeTomatoEgg extends MakeFood {
    @Override
    public void prepared() {
        System.out.println("准备西红柿+鸡蛋");
    }

    @Override
    public void doing() {
        System.out.println("起锅烧油炒西红柿");
    }

    @Override
    public void carryOut() {
        System.out.println("西红柿装盘");
    }
}
