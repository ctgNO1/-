package 模板方法模式;

public class MainTest {
    public static void main(String[] args) {
        MakeFood makeFood =new MakePepper();
        makeFood.make();//子类引用调父类方法

    }
}
