package 模板方法模式;

public abstract class MakeFood {
    //准备食材
    public  abstract  void prepared();
    //做菜
    public abstract void doing();
    //装盘
    public abstract void carryOut();

    public void make(){
        this.prepared();
        this.doing();
        this.carryOut();
    }
}
