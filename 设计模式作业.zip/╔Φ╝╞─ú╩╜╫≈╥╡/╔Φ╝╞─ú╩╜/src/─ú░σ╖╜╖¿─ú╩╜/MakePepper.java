package 模板方法模式;

public class MakePepper extends MakeFood {
    @Override
    public void prepared() {
        System.out.println("准备青椒");
    }

    @Override
    public void doing() {
        System.out.println("起锅烧油炒青椒");
    }

    @Override
    public void carryOut() {
        System.out.println("青椒装盘");
    }
}
