package 静态代理模式;

public class Main {
    public static void main(String[] args) {
        Layer layer=new Layer();
        layer.law();
    }
}
