package 静态代理模式;

//打官司接口
public interface Law {
    public  void law();
}
