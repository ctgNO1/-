package 静态代理模式;

public class Layer implements Law {
    //代理类，不仅仅要实现接口，同时还要对真实目标类进行引用
    private  Person person;
    @Override
    public void law() {
        //目标类调用自己的方法
        if (person==null){
            person=new Person();
        }
        person.law();
        this.over();
    }

//
    public void sjzj(){
        System.out.println("收集证据");
    }

    public void over(){
        System.out.println("保证案件正常结束");
    }

    //代理类
}
