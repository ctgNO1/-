package 工厂方法模式;

public interface Fruit {
    //生产水果
    public void get();
}
