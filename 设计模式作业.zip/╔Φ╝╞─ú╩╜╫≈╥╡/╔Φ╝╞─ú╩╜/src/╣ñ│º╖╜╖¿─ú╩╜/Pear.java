package 工厂方法模式;

public class Pear implements Fruit {
    @Override
    public void get() {
        System.out.println("生产梨子");
    }
}
