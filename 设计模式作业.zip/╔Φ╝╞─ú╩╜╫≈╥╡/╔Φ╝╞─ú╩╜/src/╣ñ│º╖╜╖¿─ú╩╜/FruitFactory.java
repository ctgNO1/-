package 工厂方法模式;

//充当工厂的接口，所有的实现工作都交给具体的实现工厂来做


//如果需要生产其他的水果 ，此时也就是只需要添加一个香蕉工厂就OK了
public  interface FruitFactory {
    public Fruit getFruit();
}
