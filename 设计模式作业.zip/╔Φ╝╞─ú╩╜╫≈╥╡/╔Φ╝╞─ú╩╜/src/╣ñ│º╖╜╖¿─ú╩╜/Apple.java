package 工厂方法模式;

public class Apple implements Fruit {
    @Override
    public void get() {
        System.out.println("生产苹果");
    }
}
