package 工厂方法模式;

public class MainTest {
    public static void main(String[] args) {
        FruitFactory factory1=new AppleFactory();
       Fruit fruit1= factory1.getFruit();
       fruit1.get();

        FruitFactory factory2=new BananaFactory();
        Fruit fruit2= factory2.getFruit();
        fruit2.get();
    }
}
