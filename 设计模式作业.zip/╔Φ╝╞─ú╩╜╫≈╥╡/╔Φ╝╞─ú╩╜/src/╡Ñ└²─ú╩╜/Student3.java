package 单例模式;

/**
 * 懒汉式
 * 如何保证线程安全
 * 1。：可以在方法上加一个线程同步方法----synchronized（但是这种效率低）  线程1在访问的时候，其他线程都必须等待。
 * 2.：同步代码块
 */
public class Student3 {
    private static Student3 student2 = null;
    private Student3() {

    }
    public synchronized static Student3 getInstance() {
        if (student2 == null) {             //也就是说线程1在判断的时候 线程2new了  然后线程1 又new  就产生了多个对象地址
            student2 = new Student3();
        }
        return student2;
    }
    //注意：此时不支持多线程

}
