package 单例模式;

public class Student {
    private String name;

    //饿汉式
    private static  Student student =new Student();
    //私有化构造器
    private Student(){

    }
    //共有的获取对象方法  ，因为 将 构造器私有了 所以 只能通过类名.方法 获取 对象 所以 用 static
    public static Student getInstacne(){
//        if (student==null){
//            student=new Student();
//        }
        return student;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
