package 单例模式;

/**
 * 懒汉式
 * 如何保证线程安全
 * 1。：可以在方法上加一个线程同步方法----synchronized（但是这种效率低）  线程1在访问的时候，其他线程都必须等待。
 * 2.：同步代码块
 * 3：双重校验锁---double check
 */
public class Student4 {

    private  static Student4 student4=null;
    private Student4(){

    }

    //在下面这种情况下，同步代码块并不能保证现成的安全。
    public  static Student4 getInstance(){
        if (student4 == null){             //也就是说线程1在判断的时候 线程2new了  然后线程1 又new  就产生了多个对象地址
            synchronized (Student4.class){
                student4=new Student4();
            }

        }
        return student4;
    }
    //注意：此时不支持多线程

}
