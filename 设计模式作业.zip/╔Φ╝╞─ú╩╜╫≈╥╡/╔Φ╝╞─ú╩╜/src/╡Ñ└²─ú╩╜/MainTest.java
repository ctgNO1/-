package 单例模式;

public class MainTest {
    public static void main(String[] args) {
        //传统创建对象  无法保证一个类只产生一个实例对象。
//        System.out.println(Student.getInstacne());
//        System.out.println(Student.getInstacne());



        //懒汉式演示

    }
}
