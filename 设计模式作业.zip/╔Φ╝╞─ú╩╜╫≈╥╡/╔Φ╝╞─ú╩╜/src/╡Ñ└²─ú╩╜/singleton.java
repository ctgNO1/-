package 单例模式;

public class singleton {
}
