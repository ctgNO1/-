package 单例模式;

/**
 * 懒汉式 此种方法 不支持多线程，仅仅在单线程下没有问题
 *
 */
public class Student2 {

    private  static Student2 student2=null;
    private  Student2 (){

    }

    public static  Student2 getInstance(){
        if (student2 == null){
            student2=new Student2();
        }
        return student2;
    }
    //注意：此时不支持多线程

}
