package 动态代理模式;

public class Person implements Law {

    //称为目标类
    @Override
    public void law() {
        System.out.println("上法庭陈述事实。");
    }
}
