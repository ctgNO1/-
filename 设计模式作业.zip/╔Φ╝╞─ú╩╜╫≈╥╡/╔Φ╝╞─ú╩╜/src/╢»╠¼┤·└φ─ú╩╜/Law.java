package 动态代理模式;

//实现动态代理需要实现  java包中  InvocationHandler 接口


//打官司接口
public interface Law {
    public  void law();
}
