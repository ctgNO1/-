package 动态代理模式;

import java.lang.reflect.Proxy;

public class Main {
    public static void main(String[] args) {
        //新建person代理目标对象
        Person person =new Person();
        //将代理目标传入，创建代理回调类对象
        MyHandler myHandler = new MyHandler(person);
        //生成代理对象(用这个方法来生成代理实例)
        Law proxy= (Law) Proxy.newProxyInstance(Person.class.getClassLoader(),person.getClass().getInterfaces(),myHandler);
        //第一个参数是目标类的加载器，   第二个参数是目标类接口              第三个参数 是 代理对象
        proxy.law();

    }
}
