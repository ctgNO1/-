package 继承实现理解;

public class MainTest {
    public static void main(String[] args) {
        //多态构造
        Teacher mathTeacher1 = new MathTeacher();
        //子类构造器
        MathTeacher mathTeacher = new MathTeacher();
        mathTeacher1.eatting();
        mathTeacher.eatting();
        mathTeacher1.sing();
        mathTeacher.sing();















    }
}
