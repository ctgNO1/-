package 继承实现理解;

public class ChinaTeacher extends Teacher {

    @Override
    public void eatting() {
        super.eatting();
    }

    public ChinaTeacher() {
        System.out.println("语文老师构造方法");
    }

    @Override
    public void sing() {
        System.out.println("我拿着语文书教书");
    }

    public void  reading(){
        System.out.println("我拿着语文书读出来");
    }

    @Override
    public void running() {
        System.out.println("我拿着语文书跑步");
    }
}
