package 继承实现理解;

public interface Person {
                public   String name = null;
                public String age =null;

                public void sing();
                public void eatting();
}
