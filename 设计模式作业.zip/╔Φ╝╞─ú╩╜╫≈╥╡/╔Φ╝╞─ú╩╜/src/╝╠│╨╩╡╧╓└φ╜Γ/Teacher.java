package 继承实现理解;

public abstract class Teacher implements Person{
    @Override
    public void eatting() {
        System.out.println("我吃饭");
    }

    public abstract void running();

    public Teacher() {
        System.out.println("老师构造方法");
    }

    @Override
    public  void sing() {
        System.out.println("我拿着课本教书");
    }
}
