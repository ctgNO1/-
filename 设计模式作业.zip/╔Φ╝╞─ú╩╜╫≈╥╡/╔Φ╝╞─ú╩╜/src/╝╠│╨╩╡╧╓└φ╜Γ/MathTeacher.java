package 继承实现理解;

public class MathTeacher extends Teacher {


    @Override
    public void eatting() {
        System.out.println("我拿着数学书吃饭");
    }

    public MathTeacher() {
        super();
    }

    @Override
    public void sing() {
        System.out.println("我拿着数学书唱歌");
    }

    @Override
    public void running() {
        System.out.println("我拿着数学书跑步");
    }

    public void watching(){
        System.out.println("我是都有方法");
    }

}
