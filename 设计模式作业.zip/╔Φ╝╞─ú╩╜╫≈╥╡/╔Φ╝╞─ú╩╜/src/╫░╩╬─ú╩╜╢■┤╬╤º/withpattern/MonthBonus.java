package 装饰模式二次学.withpattern;

import 装饰模式二次学.nopattern.UserBox;

/**
 * 用来做 3% 计算的
 */

public class MonthBonus extends Decorator {
    public MonthBonus(Boss d) {
        super(d);
    }

    //2.自己增加 3% 的方法
    @Override
    public double calcBonus(String name){
        //1.先有一个 基本的方法
        double money = d.calcBonus(name);
        //在基本结果之上添加自己的
        double bonus = UserBox.getUser(name).getSalary() * 0.03;
        System.out.println(name+"当月基本奖金"+bonus);
        return money+bonus;
    }
}
