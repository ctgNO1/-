package 装饰模式二次学.withpattern;


/**
 * 这个类有一个计算的方法
 */
public class Bonus implements Boss {
    @Override
    public double calcBonus(String name){
        //每一个人 都一个基本奖金 3%,我们认为3%的奖金以后可能不发
        //想要把所有额外的部分都拆出去

        System.out.println("默认没有奖金");
        return 0;
    }

    //

}
