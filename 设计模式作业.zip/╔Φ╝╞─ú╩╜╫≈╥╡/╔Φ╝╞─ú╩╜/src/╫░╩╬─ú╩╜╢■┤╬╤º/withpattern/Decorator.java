package 装饰模式二次学.withpattern;

/**
 * 这个规则的出现就是装饰着
 * 这个规则的出现 是为了 让所有添加的对象都可以随意 套 而非按照某种顺序来。
 */

public abstract class Decorator implements Boss {

    protected Boss d;
    protected Decorator(Boss d) {
        this.d = d;
    }


   @Override
   abstract public double calcBonus(String name);
}
