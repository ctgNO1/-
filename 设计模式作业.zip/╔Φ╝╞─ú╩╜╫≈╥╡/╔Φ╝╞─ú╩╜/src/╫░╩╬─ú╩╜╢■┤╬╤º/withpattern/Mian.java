package 装饰模式二次学.withpattern;

//高级流 原理 就是 装饰模式

public class Mian {
    public static void main(String[] args) {
        //1.创建一个对象
        Bonus b= new Bonus();  //原始对象不能套别人  其他都可以套
        extraBonus eb=new extraBonus(b);
        MonthBonus mb=new MonthBonus(eb);
        double aTuo = mb.calcBonus("ATuo");
        System.out.println(aTuo);
    }
}
