package 装饰模式二次学.withpattern;

public interface Boss {
    //顶级的规则 让 原始对象的方法和Decorator 的方法名字统一
    //统一了以后用户 就分不清了 用起来方便些
    public double calcBonus(String name);

}
