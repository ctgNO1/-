package 装饰模式二次学.withpattern;

import 装饰模式二次学.nopattern.UserBox;

public class extraBonus extends Decorator {


    public extraBonus(Boss d) {
        super(d);
    }

    @Override
    public double calcBonus(String name){
        double money = d.calcBonus(name);

        //自己干
        double bonus = UserBox.getUser(name).getSalary() * 0.01;
        System.out.println(name+"超额绩效奖金"+bonus);
        return money+bonus;
    }
}
