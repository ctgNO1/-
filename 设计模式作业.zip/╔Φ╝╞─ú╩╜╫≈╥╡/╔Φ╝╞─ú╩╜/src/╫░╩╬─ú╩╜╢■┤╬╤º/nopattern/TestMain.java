package 装饰模式二次学.nopattern;

public class TestMain {
    public static void main(String[] args) {
        //1.创建 一个对象   计算奖金
        Bonus b=new Bonus();
        double andy = b.calcBonus("Andy");
        System.out.println(andy);
    }
}
