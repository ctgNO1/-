package 装饰模式二次学.nopattern;

import java.util.HashMap;
import java.util.Map;

/**
 * 一个集合 装好多个员工
 */
public class UserBox {


    private static Map<String,User> userBox;

    //静态块，在创建当前类时就  初始化集合 并且存入好多用户
    static {
        userBox=new HashMap<>();
        userBox.put("Andy",new User("安迪",4000,"普通"));
        userBox.put("BoGe",new User("博格",6000,"普通"));
        userBox.put("ATuo",new User("阿托",8000,"经理"));

    }

    //根据name来获取某一个用户的
    public static User getUser(String name){
        return userBox.get(name);
    }

    //获取集合
    public static Map<String,User> getUserBox(){
        return userBox;
    }
}
