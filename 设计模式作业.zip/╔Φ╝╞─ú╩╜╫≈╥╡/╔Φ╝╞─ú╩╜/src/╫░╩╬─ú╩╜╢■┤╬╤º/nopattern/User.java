package 装饰模式二次学.nopattern;

/**
 * 这个类用来描述一个人
 * 表示一个销售员工
 *
 * 名字   销售额    身份（普通or经理）
 */
public class User {
    private String name;
    private double salary;
    private String identity;

    public User(String name, double salary, String identity) {
        this.name = name;
        this.salary = salary;
        this.identity = identity;
    }

    public String getName() {
        return name;
    }

    public double getSalary() {
        return salary;
    }

    public String getIdentity() {
        return identity;
    }
}
