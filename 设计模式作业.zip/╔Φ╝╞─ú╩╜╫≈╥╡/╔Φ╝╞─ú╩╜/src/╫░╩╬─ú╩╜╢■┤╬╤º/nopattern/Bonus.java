package 装饰模式二次学.nopattern;

import java.util.Map;
import java.util.Set;

/**
 * 用来计算每个员工奖金的类
 */
public class Bonus {

    //设计一个方法 用来 计算奖金
    public double calcBonusOriginal(String name) {
        //1.创建一个变量存储最终的结果
        double result = 0;
        //2.获取用户
        User user = UserBox.getUser(name);
        //3.每个人都计算基本的奖金
        result+=user.getSalary()*0.03;
        System.out.println(user.getName()+"基本奖金"+result);
        //4.判断是否超过了5K
        if (user.getSalary()>=5000){
            result+=user.getSalary()*0.01;
            System.out.println(user.getName()+"超哥奖金"+result);
        }
        //5.如果这个人是一个经理
        if (user.getIdentity().equals("经理")){
            //计算整个销售部的总业绩 的 1%
            double sum = 0;//计算总额
            Map<String, User> map = UserBox.getUserBox();
            for (String key : map.keySet()) {
               sum+=map.get(key).getSalary();
            }
            //总额 1% 加到我的工资里
            result+=sum*0.01;
            System.out.println(user.getName()+"团队奖金");
        }
        return result;
    }


    //==================================
    //一个方法最好只做一件事情------把方法拆分
    //设计三个小弟  分别处理三种不同情况的计算
    public double calcBonus(String name){
        double result=0;
        //计算基本奖金(所有人都一样  招小弟)
       result+= this.monthBonus(name);
        result+=this.extraBonus(name);
        result+=this.teamBonus(name);
        return result;
    }

    //小弟负责基本的计算  没人都一样 3%
    private double monthBonus(String name){
        User user = UserBox.getUser(name);
       double bonus= user.getSalary()*0.03;
        System.out.println(name+"当月销售奖金"+bonus);
        return bonus;
    }
    //小弟 超过了 标准 计算额外奖金
    private double extraBonus(String name){
        User user = UserBox.getUser(name);
        if(user.getSalary()>=5000){
            double bonus=user.getSalary()*0.01;
            System.out.println(name+"超额绩效奖金"+bonus);
            return bonus;
        }
        return 0;
    }
    //r如果是一个经理 计算 团队奖金
    private  double teamBonus(String name){
        User user = UserBox.getUser(name);
        if ("经理".equals(user.getName())){
            double sum=0;
            Map<String, User> map = UserBox.getUserBox();
            for (String key : map.keySet()) {
                sum+=map.get(key).getSalary();
            }
            double bonus=sum*0.01;
            System.out.println(name+"带领团队奖金"+bonus);
        }
        return 0;
    }




}
