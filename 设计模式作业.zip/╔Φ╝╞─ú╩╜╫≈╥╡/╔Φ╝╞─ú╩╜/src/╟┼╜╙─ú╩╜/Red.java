package 桥接模式;

public class Red implements Color {
    @Override
    public void print() {
        System.out.println("红色");
    }
}
