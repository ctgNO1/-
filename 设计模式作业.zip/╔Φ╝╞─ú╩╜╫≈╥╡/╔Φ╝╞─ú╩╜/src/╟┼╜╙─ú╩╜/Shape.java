package 桥接模式;

public abstract class Shape {
    //抽象类内引用color
    private Color color;

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public Shape(Color color) {
        this.color = color;
    }
    //打印形状
    public abstract void show();
}
