package 桥接模式;

public class Circle extends Shape {
    public Circle(Color color) {
        super(color);
    }


    @Override
    public void show() {
        System.out.println("圆形");
        this.getColor().print();
    }
}
