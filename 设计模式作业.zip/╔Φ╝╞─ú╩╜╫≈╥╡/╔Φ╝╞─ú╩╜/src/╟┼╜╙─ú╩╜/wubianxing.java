package 桥接模式;

public class wubianxing extends Shape {
    public wubianxing(Color color) {
        super(color);
    }

    @Override
    public void show() {
        System.out.println("五边形");
        this.getColor().print();
    }
}
