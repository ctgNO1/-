package 桥接模式;

public interface Color {
    public void print();
}
