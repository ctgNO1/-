package 桥接模式;

public class Black implements Color {
    @Override
    public void print() {
        System.out.println("黑色");
    }
}
