package 桥接模式;

public class MainTest {
    public static void main(String[] args) {
        Color red=new Red();
        Color black=new Black();
        Shape circle=new Circle(red);
        circle.show();
    }
}
