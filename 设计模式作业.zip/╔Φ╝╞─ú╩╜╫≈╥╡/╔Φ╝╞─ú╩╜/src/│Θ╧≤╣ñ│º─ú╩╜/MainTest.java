package 抽象工厂模式;

public class MainTest {
    public static void main(String[] args) {
        //获取进口的工厂
        FruitFactory factory1=new FruitJkFactory();
        Fruit apple=factory1.getApple();//获取进口苹果对象
        apple.get();
        Fruit banana=factory1.getBanana();
        banana.get();
    }
}
