package 抽象工厂模式;

public class FruitJkFactory implements FruitFactory{
    @Override
    public Fruit getApple() {
        return new AppleJK();
    }

    @Override
    public Fruit getBanana() {
        return new BananaJK();
    }
}
