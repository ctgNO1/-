package 抽象工厂模式;

public class FruitPTFactory implements FruitFactory {
    @Override
    public Fruit getApple() {
        return new ApplePT();
    }

    @Override
    public Fruit getBanana() {
        return new BananaPT();
    }
}
