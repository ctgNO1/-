package 抽象工厂模式;

public interface FruitFactory {

    public Fruit getApple();
    public Fruit getBanana();

}
