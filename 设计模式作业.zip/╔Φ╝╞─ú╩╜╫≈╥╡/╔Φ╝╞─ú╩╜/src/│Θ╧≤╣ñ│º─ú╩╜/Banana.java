package 抽象工厂模式;

public abstract class Banana implements Fruit  {
    @Override
    public abstract void get();


}
