package 抽象工厂模式;

public abstract class Apple implements Fruit {
    @Override
    public abstract void get();
}
