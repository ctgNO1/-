package 抽象工厂模式;

public class BananaJK extends Banana {
    @Override
    public void get() {
        System.out.println("生产进口香蕉");
    }
}
